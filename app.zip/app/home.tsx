import React from "react";
import { SafeAreaView, StatusBar } from "react-native";
import HomeScreen from "../Screens/homescreen";
import { themeColors } from "../utils/theme-utils";

export default function App() {
  return (
    <SafeAreaView style={{ flex: 1 }}>
      <StatusBar backgroundColor={themeColors.blue} barStyle="light-content" />
      <HomeScreen />
    </SafeAreaView>
  );
}
